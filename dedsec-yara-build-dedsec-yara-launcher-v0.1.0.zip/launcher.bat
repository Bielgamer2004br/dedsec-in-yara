@echo off
python src/main.py --game-dir %MELTY_GAME_PATH% --game2-dir %WATCHDOGS2_PATH%
